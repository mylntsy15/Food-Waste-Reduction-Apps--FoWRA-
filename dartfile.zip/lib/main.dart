import 'package:flutter/material.dart';
import 'database_helper.dart';
import 'homepage.dart';
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart';

void main() {

  initializeDateFormatting('ms_MY', null).then((_) {
    runApp(MyApp());
  });
}
class MyApp extends StatelessWidget {
  final HomePageModel _model = HomePageModel();

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomePageWidget(model: _model),
    );
  }
}