import 'package:flutter/material.dart';
import 'package:fowra/homepage.dart';
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart';





class FoodItem {
  String name;
  DateTime expirationDate;

  FoodItem({required this.name, required this.expirationDate});
}

class MyApp extends StatelessWidget {

  @override
  Widget build(BuildContext context) {

    var malaysiaTime = DateTime.now().toUtc().add(Duration(hours: 8));

    // Format the date and time
    var formatter = DateFormat('EEEE, yyyy-MM-dd - kk:mm', 'ms_MY');
    String formatDate = formatter.format(malaysiaTime);

    return MaterialApp(
      title: 'Set Reminder',
      theme: ThemeData(
        appBarTheme: AppBarTheme(
          backgroundColor: Color(0xFFFFFAF0),
          centerTitle: true,
          titleTextStyle: TextStyle(
            fontFamily: 'PlayfairDisplay',
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
        ),
      ),
      home: MyHomePage(formatDate: formatDate),
    );
  }
}

class MyHomePage extends StatefulWidget {
  final String formatDate;

  MyHomePage({required this.formatDate});

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  List<FoodItem> foodItems = [];

  Future<void> _showAddFoodDialog(BuildContext context) async {
    TextEditingController nameController = TextEditingController();
    DateTime currentDate = DateTime.now();
    DateTime? selectedDate = currentDate;

    await showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
        title: Text('Add Food Item'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameController,
              decoration: InputDecoration(labelText: 'Food Name'),
            ),
            SizedBox(height: 16),
            ListTile(
              title: Text('Expiration Date'),
              subtitle: Text(
                selectedDate != null
                    ? DateFormat('yyyy-MM-dd').format(selectedDate!)
                    : 'Select date',
              ),
              onTap: () async {
                DateTime? pickedDate = await showDatePicker(
                  context: context,
                  initialDate: currentDate,
                  firstDate: currentDate,
                  lastDate: DateTime(currentDate.year + 1),
                );

                if (pickedDate != null && pickedDate != selectedDate) {
                  setState(() {
                    selectedDate = pickedDate;
                  });
                }
              },
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              if (nameController.text.isNotEmpty && selectedDate != null) {
                setState(() {
                  foodItems.add(
                    FoodItem(
                      name: nameController.text,
                      expirationDate: selectedDate!,
                    ),
                  );
                });
              }
              Navigator.pop(context);
            },
            child: Text('Add'),
          ),
        ],
      );
    },
    );
  }
  void _showReminderDialog(BuildContext context, FoodItem foodItem) {
    // Implement your reminder setting logic here
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Set Reminder'),
          content: Text('Set reminder for ${foodItem.name}'),
          actions: [
            TextButton(
              onPressed: () {
                // Implement the reminder setting action
                Navigator.pop(context);
              },
              child: Text('Set Reminder'),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text('Cancel'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: Padding(
          padding: const EdgeInsets.all(0.0),
          child: IconButton(
            icon: Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => HomePageWidget(model: HomePageModel())),
              );
            },
          )
        ),
        title: Text(
          'Expiration Tracking',
          style: TextStyle(
            fontSize: 25,
            fontFamily: 'PlayfairDisplay',
            color: Colors.white,
            letterSpacing: 1.5,
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.pinkAccent.withOpacity(0.7),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(bottom: Radius.circular(15)),
        ),
        elevation: 0,
        actions: [
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: IconButton(
              icon: Icon(Icons.help, color: Colors.white, size: 25.0),
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return AlertDialog(
                      title: Text(
                        'Help',
                        style: TextStyle(
                          fontSize: 30,
                          fontFamily: 'Signika',
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      content: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            'Welcome!',
                            style: TextStyle(
                              fontSize: 20,
                              fontFamily: 'PlayfairDisplay',
                            ),
                          ),
                          SizedBox(height: 10),
                          Text(
                            'Make a Donation provides you with the opportunity to request a donation, and a dedicated representative from the food bank will promptly arrange to pick it up at your convenience.',
                            style: TextStyle(
                              fontSize: 15,
                            ),
                          ),
                          SizedBox(height: 10),
                          Text(
                            'Your Donations provides you with the list of donation that you has been created.',
                            style: TextStyle(
                              fontSize: 15,
                            ),
                          ),
                          SizedBox(height: 10),
                          Text(
                            'Contact us if any problem occur!',
                            style: TextStyle(
                              fontSize: 15,
                            ),
                          ),
                        ],
                      ),
                      actions: [
                        TextButton(
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          child: Text(
                            'Close',
                            style: TextStyle(
                              fontSize: 20,
                              fontFamily: 'Sans',
                              color: Colors.pink,
                            ),
                          ),
                        ),
                      ],
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(
              '${widget.formatDate}',
              style: TextStyle(fontSize: 18),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: foodItems.length,
              itemBuilder: (context, index) {
                return Dismissible(
                  key: Key(foodItems[index].name),
                  direction: DismissDirection.endToStart,
                  background: Container(
                    color: Colors.red,
                    child: Align(
                      alignment: Alignment.centerRight,
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Icon(
                          Icons.delete,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                  onDismissed: (direction) {
                    setState(() {
                      foodItems.removeAt(index);
                    });
                  },
                  child: ListTile(
                    title: Text(foodItems[index].name),
                    subtitle: Text(
                      'Expires on ${DateFormat('yyyy-MM-dd').format(
                          foodItems[index].expirationDate)}',
                    ),
                    onTap: () {
                      // Open the reminder dialog
                      _showReminderDialog(context, foodItems[index]);
                    },
                  ),
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _showAddFoodDialog(context);
        },
        child: Icon(Icons.add),
        backgroundColor: Colors.pinkAccent.withOpacity(0.7),
      ),
    );
  }
}






