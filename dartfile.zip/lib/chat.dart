import 'package:flutter/material.dart';


class ChatPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: Text(
            '_nurinadnii',
            style: TextStyle(
              color: Colors.black,
            ),
          ),
          centerTitle: true,
          flexibleSpace: Container(
            decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.yellow.shade300,
                    Colors.pink.shade100
                  ],
                )
            ),
          ),
          leading: Icon(Icons.keyboard_arrow_left, color: Colors.black,),
          actions: <Widget>[
            Icon(Icons.list,color: Colors.black,
              size: 35,
            ),
            SizedBox(width: 20,),
            Icon(Icons.create,color: Colors.black,),
          ],
          backgroundColor: Color(0xFFFFFAF0),
        ),
        bottomNavigationBar: Container(
          height: 50,
          color: Colors.white12,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Icon(Icons.camera_alt,
                size: 30,
                color: Colors.blue,
              ),
              Text('Camera',style: TextStyle(color: Colors.blue,fontSize: 20),
              ),
            ],
          ),
        ),
        body: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              Container(
                height: 30,
                width: double.infinity,
                margin: EdgeInsets.symmetric(vertical: 20,horizontal: 10),
                padding: EdgeInsets.all(5),
                decoration: BoxDecoration(
                  color: Colors.black12,
                  borderRadius: BorderRadius.circular(5),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        Icon(Icons.search),
                        SizedBox(width: 5,),
                        Text('Search'),
                      ],
                    ),
                    Icon(Icons.calendar_view_day),
                  ],
                ),
              ),

              SizedBox(width: 25,),
              Container(
                margin: EdgeInsets.all(20),
                child: Row(
                  children: <Widget>[
                    Text(
                      'Primary',
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    SizedBox(width: 25),
                    Text(
                        'General',
                        style:TextStyle(fontSize: 20,color: Colors.black54)
                    ),
                  ],
                ),
              ),
              Divider(color: Colors.black38,),

              ListTile(
                title: Text('Username'),
                subtitle: Text('Active 13 min ago'),
                leading: CircleAvatar(
                  backgroundColor: Colors.indigo,
                  radius:30,
                ),
                trailing:Icon(
                  Icons.camera_alt,
                  size: 35,
                ),
              ),
              SizedBox(height: 10,),
              ListTile(
                title: Text('Username'),
                subtitle: Text('Active 13 min ago'),
                leading: CircleAvatar(
                  backgroundColor: Colors.indigo,
                  radius:30,
                ),
                trailing:Icon(
                  Icons.camera_alt,
                  size: 35,
                ),
              ),
              SizedBox(height: 10,),
              ListTile(
                title: Text('Username'),
                subtitle: Text('Active 13 min ago'),
                leading: CircleAvatar(
                  backgroundColor: Colors.indigo,
                  radius:30,
                ),
                trailing:Icon(
                  Icons.camera_alt,
                  size: 35,
                ),
              ),
              SizedBox(height: 10,),
              ListTile(
                title: Text('Username'),
                subtitle: Text('Active 13 min ago'),
                leading: CircleAvatar(
                  backgroundColor: Colors.indigo,
                  radius:30,
                ),
                trailing:Icon(
                  Icons.camera_alt,
                  size: 35,
                ),
              ),SizedBox(height: 10,),
              ListTile(
                title: Text('Username'),
                subtitle: Text('Active 13 min ago'),
                leading: CircleAvatar(
                  backgroundColor: Colors.indigo,
                  radius:30,
                ),
                trailing:Icon(
                  Icons.camera_alt,
                  size: 35,
                ),
              ),
              SizedBox(height: 10,),
              ListTile(
                title: Text('Username'),
                subtitle: Text('Active 13 min ago'),
                leading: CircleAvatar(
                  backgroundColor: Colors.indigo,
                  radius:30,
                ),
                trailing:Icon(
                  Icons.camera_alt,
                  size: 35,
                ),
              ),
              SizedBox(height: 10,),
              ListTile(
                title: Text('Username'),
                subtitle: Text('Active 13 min ago'),
                leading: CircleAvatar(
                  backgroundColor: Colors.indigo,
                  radius:30,
                ),
                trailing:Icon(
                  Icons.camera_alt,
                  size: 35,
                ),
              ),
              SizedBox(height: 10,),
              ListTile(
                title: Text('Username'),
                subtitle: Text('Active 13 min ago'),
                leading: CircleAvatar(
                  backgroundColor: Colors.indigo,
                  radius:30,
                ),
                trailing:Icon(
                  Icons.camera_alt,
                  size: 35,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}




