import 'package:flutter/material.dart';

class ItemInventory extends StatefulWidget {
  @override
  _ItemInventoryState createState() => _ItemInventoryState();
}

class _ItemInventoryState extends State<ItemInventory> {
  List<FoodItem> foodItems = [];

  void addItem(FoodItem newItem) {
    setState(() {
      foodItems.add(newItem);
    });
    Navigator.pop(context); // Go back to the previous screen
  }

  void removeItem(int index) {
    setState(() {
      foodItems.removeAt(index);
    });
  }

  void navigateToAddItem() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ManualPage(
          onAddItem: addItem,
        ),
      ),
    );
  }

  void navigateToYourItems() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => YourItemsPage(foodItems: foodItems),
      ),
    );
  }

  void navigateToRemoveItem() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => RemoveItemPage(
          foodItems: foodItems,
          onRemoveItem: removeItem,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'FOWRA',
          style: TextStyle(
              fontSize: 25,
              fontFamily: 'PlayfairDisplay',
              color: Colors.white,
              letterSpacing: 1.5),
        ),
        centerTitle: true,
        backgroundColor: Colors.pinkAccent.withOpacity(0.7),
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(bottom: Radius.circular(15))),
        elevation: 0,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: navigateToAddItem,
              child: Text('Add Your Item'),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: navigateToYourItems,
              child: Text('Your Item'),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: navigateToRemoveItem,
              child: Text('Remove Your Item'),
            ),
          ],
        ),
      ),
    );
  }
}

class ManualPage extends StatefulWidget {
  final Function(FoodItem) onAddItem;

  ManualPage({required this.onAddItem});

  @override
  _ManualPageState createState() => _ManualPageState();
}

class _ManualPageState extends State<ManualPage> {
  final TextEditingController itemNameController = TextEditingController();
  final TextEditingController quantityController = TextEditingController();
  final TextEditingController detailsController = TextEditingController();

  DateTime? selectedDate;

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime(2101),
    );

    if (picked != null && picked != DateTime.now()) {
      setState(() {
        selectedDate = DateTime(picked.year, picked.month, picked.day);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: Padding(
          padding: const EdgeInsets.all(0.0),
          child: IconButton(
            icon: Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
        ),
        title: Text(
          'Add Your Item',
          style: TextStyle(
              fontSize: 25,
              fontFamily: 'PlayfairDisplay',
              color: Colors.white,
              letterSpacing: 1.5),
        ),
        centerTitle: true,
        backgroundColor: Colors.pinkAccent.withOpacity(0.7),
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(bottom: Radius.circular(15))),
        elevation: 0,
        actions: [
          Padding(
            padding: const EdgeInsets.all(10.0), // Adjust padding as needed
            child: IconButton(
              icon: Icon(Icons.help, color: Colors.white, size: 25.0),
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return AlertDialog(
                      title: Text('Help', style: TextStyle(fontSize: 30, fontFamily: 'Signika', fontWeight: FontWeight.bold),),
                      content: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          // SizedBox(height: 10),
                          // Text(
                          //   'This screen displays pending donation request and history of past request.',
                          // ),
                          SizedBox(height: 10),
                          Text(
                            'Item Name: Enter the name of the item you want to add.',
                            style: TextStyle(fontSize: 15,),
                          ),
                          SizedBox(height: 10),
                          Text(
                            'Quantity: Specify the quantity of the item.',
                            style: TextStyle(fontSize: 15,),
                          ),
                          SizedBox(height: 10),
                          Text(
                            ('Expiration Date: Enter the expiration date for the item.'),
                            style: TextStyle(fontSize: 15, ),
                          ),
                          SizedBox(height: 10),
                          Text(
                            'Details/Notes: Provide additional details or notes about the item (optional).',
                            style: TextStyle(fontSize: 15, ),
                          ),
                        ],
                      ),
                      actions: [
                        TextButton(
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          child: Text('Close', style: TextStyle(fontSize: 20, fontFamily: 'Sans', color: Colors.pink),),
                        ),
                      ],
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(height: 25.0),
            _buildRoundedSquareTextField('Item Name', itemNameController),
            SizedBox(height: 20.0),
            _buildRoundedSquareTextField('Quantity', quantityController),
            SizedBox(height: 20.0),
            InkWell(
              onTap: () => _selectDate(context),
              child: IgnorePointer(
                child: _buildRoundedSquareTextField(
                  'Expiration Date',
                  TextEditingController(text: selectedDate?.toLocal().toString().split(' ')[0] ?? ''),
                ),
              ),
            ),
            SizedBox(height: 20.0),
            _buildRoundedSquareTextField('Details/Notes', detailsController, height: 160.0),
            SizedBox(height: 25.0),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10.0),
                    gradient: LinearGradient(
                      colors: [
                        Colors.yellow.shade300,
                        Colors.pink.shade100,
                      ],
                    ),
                  ),
                  child: ElevatedButton(
                    onPressed: () {
                      if (_validateFields()) {
                        FoodItem newItem = FoodItem(
                          itemName: itemNameController.text,
                          quantity: quantityController.text,
                          expirationDate: selectedDate,
                          details: detailsController.text,
                        );
                        widget.onAddItem(newItem);
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => CameraPage(newItem: newItem),
                          ),
                        );
                      }
                    },
                    child: Text(
                      'Continue...',
                      style: TextStyle(
                        fontFamily: 'EBGaramond',
                        fontWeight: FontWeight.w900,
                        fontSize: 16.0,
                        color: Colors.black,
                      ),
                    ),
                    style: ElevatedButton.styleFrom(
                      primary: Colors.transparent,
                      elevation: 0,
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 35.0),
            Container(
              margin: EdgeInsets.symmetric(vertical: 8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ElevatedButton(
                    onPressed: () {
                      navigateToScanPage(context);
                    },
                    style: ElevatedButton.styleFrom(
                      primary: Colors.orange[100],
                    ),
                    child: Container(
                      width: 120.0,
                      height: 50.0,
                      child: Center(
                        child: Text(
                          'Scan',
                          style: TextStyle(
                            fontFamily: 'PlayfairDisplay',
                            fontSize: 20.0,
                            fontWeight: FontWeight.w900,
                            color: Colors.black,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    width: 10.0,
                    height: 50.0,
                    color: Colors.black,
                  ),
                  ElevatedButton(
                    onPressed: () {
                      navigateToManualPage(context);
                    },
                    style: ElevatedButton.styleFrom(
                      primary: Colors.orange[100],
                    ),
                    child: Container(
                      width: 120.0,
                      height: 50.0,
                      child: Center(
                        child: Text(
                          'Manually',
                          style: TextStyle(
                            fontFamily: 'PlayfairDisplay',
                            fontSize: 20.0,
                            fontWeight: FontWeight.w900,
                            color: Colors.black,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRoundedSquareTextField(String label, TextEditingController? controller, {double height = 50.0}) {
    return Container(
      width: 300.0,
      height: height,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10.0),
        color: Colors.yellow[50],
      ),
      margin: EdgeInsets.symmetric(vertical: 8.0),
      padding: EdgeInsets.symmetric(horizontal: 16.0),
      child: controller != null
          ? TextField(
        controller: controller,
        style: TextStyle(fontFamily: 'EBGaramond'),
        maxLines: null,
        decoration: InputDecoration(
          border: InputBorder.none,
          hintText: label,
        ),
      )
          : Center(
        child: Text(
          label,
          style: TextStyle(fontFamily: 'EBGaramond'),
        ),
      ),
    );
  }

  void navigateToScanPage(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ScanPage(),
      ),
    );
  }

  void navigateToManualPage(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ManualPage(
          onAddItem: widget.onAddItem,
        ),
      ),
    );
  }

  Widget _helpText(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0),
      child: Text(text),
    );
  }

  bool _validateFields() {
    if (itemNameController.text.isEmpty ||
        quantityController.text.isEmpty ||
        selectedDate == null) {
      showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: Text('Missing Information'),
            content: Text('Please fill in all required fields (Item Name, Quantity, Expiration Date).'),
            actions: <Widget>[
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: Text('OK'),
              ),
            ],
          );
        },
      );
      return false;
    }
    return true;
  }
}

class YourItemsPage extends StatelessWidget {
  final List<FoodItem> foodItems;

  YourItemsPage({required this.foodItems});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: Padding(
          padding: const EdgeInsets.all(0.0),
          child: IconButton(
            icon: Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
        ),
        title: Text(
          'Your Item',
          style: TextStyle(
              fontSize: 25,
              fontFamily: 'PlayfairDisplay',
              color: Colors.white,
              letterSpacing: 1.5),
        ),
        centerTitle: true,
        backgroundColor: Colors.pinkAccent.withOpacity(0.7),
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(bottom: Radius.circular(15))),
        elevation: 0,
        actions: [
          Padding(
            padding: const EdgeInsets.all(10.0), // Adjust padding as needed
            child: IconButton(
              icon: Icon(Icons.help, color: Colors.white, size: 25.0),
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return AlertDialog(
                      title: Text('Help', style: TextStyle(fontSize: 30, fontFamily: 'Signika', fontWeight: FontWeight.bold),),
                      content: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            'Welcome!',
                            style: TextStyle(fontSize: 20, fontFamily: 'PlayfairDisplay',),
                          ),
                          // SizedBox(height: 10),
                          // Text(
                          //   'This screen displays pending donation request and history of past request.',
                          // ),
                          SizedBox(height: 10),
                          Text(
                            'Here all your latest item inventory.',
                            style: TextStyle(fontSize: 15,),
                          ),
                          Text(
                            'Contact us if any problem occur!',
                            style: TextStyle(fontSize: 15, ),
                          ),
                        ],
                      ),
                      actions: [
                        TextButton(
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          child: Text('Close', style: TextStyle(fontSize: 20, fontFamily: 'Sans', color: Colors.pink),),
                        ),
                      ],
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          SizedBox(height: 10.0),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              decoration: InputDecoration(
                labelText: 'Search Items',
                prefixIcon: Icon(Icons.search),
              ),
              onChanged: (value) {
                // Implement item search logic
              },
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: foodItems.length,
              itemBuilder: (context, index) {
                return _buildFoodItemBox(foodItems[index]);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFoodItemBox(FoodItem item) {
    return Container(
      margin: EdgeInsets.all(8.0),
      padding: EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10.0),
        gradient: LinearGradient(
          colors: [
            Colors.yellow.shade300,
            Colors.pink.shade100,
          ],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.5),
            spreadRadius: 2,
            blurRadius: 5,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            item.itemName,
            style: TextStyle(
              fontSize: 18.0,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 8.0),
          Text('Quantity: ${item.quantity}'),
          Text('Expiration Date: ${item.formattedDate}'),
          Text('Details/Notes: ${item.details.isEmpty ? '-' : item.details}'),
        ],
      ),
    );
  }
}

class RemoveItemPage extends StatefulWidget {
  final List<FoodItem> foodItems;
  final Function(int) onRemoveItem;

  RemoveItemPage({required this.foodItems, required this.onRemoveItem});

  @override
  _RemoveItemPageState createState() => _RemoveItemPageState();
}

class _RemoveItemPageState extends State<RemoveItemPage> {
  TextEditingController searchController = TextEditingController();
  List<FoodItem> filteredItems = [];
  List<FoodItem> removedItems = [];
  List<FoodItem> localCopy = [];

  @override
  void initState() {
    super.initState();
    filteredItems.addAll(widget.foodItems);
    localCopy.addAll(widget.foodItems);
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        // Reset changes when the back button is pressed
        widget.foodItems.clear();
        widget.foodItems.addAll(localCopy);
        return true;
      },
      child: Scaffold(
        appBar: AppBar(
          leading: Padding(
            padding: const EdgeInsets.all(0.0),
            child: IconButton(
              icon: Icon(Icons.arrow_back, color: Colors.white),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
          ),
          title: Text(
            'Remove Your Item',
            style: TextStyle(
                fontSize: 25,
                fontFamily: 'PlayfairDisplay',
                color: Colors.white,
                letterSpacing: 1.5),
          ),
          centerTitle: true,
          backgroundColor: Colors.pinkAccent.withOpacity(0.7),
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.vertical(bottom: Radius.circular(15))),
          elevation: 0,
          actions: [
            Padding(
              padding: const EdgeInsets.all(10.0), // Adjust padding as needed
              child: IconButton(
                icon: Icon(Icons.help, color: Colors.white, size: 25.0),
                onPressed: () {
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        title: Text('Help', style: TextStyle(fontSize: 30, fontFamily: 'Signika', fontWeight: FontWeight.bold),),
                        content: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              'Welcome!',
                              style: TextStyle(fontSize: 20, fontFamily: 'PlayfairDisplay',),
                            ),
                            // SizedBox(height: 10),
                            // Text(
                            //   'This screen displays pending donation request and history of past request.',
                            // ),
                            SizedBox(height: 10),
                            Text(
                              'Removing items from Your Item is a quick and simple process that ensures your kitchen inventory is always in sync with reality.',
                              style: TextStyle(fontSize: 15,),
                            ),
                            SizedBox(height: 10),
                            Text(
                              'Thank you for your commitment to reducing food waste with FOWRA <3',
                              style: TextStyle(fontSize: 15,),
                            ),
                            SizedBox(height: 10),
                            Text(
                              'Contact us if any problem occur!',
                              style: TextStyle(fontSize: 15, ),
                            ),
                          ],
                        ),
                        actions: [
                          TextButton(
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            child: Text('Close', style: TextStyle(fontSize: 20, fontFamily: 'Sans', color: Colors.pink),),
                          ),
                        ],
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
        body: Column(
          children: [
            SizedBox(height: 10.0),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                controller: searchController,
                decoration: InputDecoration(
                  labelText: 'Search Items',
                  prefixIcon: Icon(Icons.search),
                ),
                onChanged: (value) {
                  filterItems(value);
                },
              ),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: filteredItems.length,
                itemBuilder: (context, index) {
                  return _buildFoodItemBox(filteredItems[index], index);
                },
              ),
            ),
            ElevatedButton(
              onPressed: () {
                // Submit changes
                widget.foodItems.clear();
                widget.foodItems.addAll(localCopy);
                // Handle removed items (you can use removedItems list)
                removedItems.forEach((removedItem) {
                  widget.onRemoveItem(localCopy.indexOf(removedItem));
                });
                // Clear removed items list
                removedItems.clear();
                // Navigate to home page
                Navigator.popUntil(context, ModalRoute.withName('/'));
              },
              style: ElevatedButton.styleFrom(
                primary: Colors.yellow[100], // Set the button's background color to transparent
                side: BorderSide(color: Colors.black), // Set the button's border color to black
              ),
              child: Text(
                'Submit',
                style: TextStyle(
                  fontFamily: 'PlayfairDisplay',
                  fontWeight: FontWeight.w900,
                  fontSize: 30.0,
                  color: Colors.black,
                ),
              ),
            ),
            SizedBox(height: 30.0),
          ],
        ),
      ),
    );
  }


  Widget _buildFoodItemBox(FoodItem item, int index) {
    return Container(
      margin: EdgeInsets.all(8.0),
      padding: EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10.0),
        gradient: LinearGradient(
          colors: [
            Colors.yellow.shade300,
            Colors.pink.shade100,
          ],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.5),
            spreadRadius: 2,
            blurRadius: 5,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
        Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            item.itemName,
            style: TextStyle(
              fontSize: 18.0,
              fontWeight: FontWeight.bold,
            ),
          ),
          IconButton(
            icon: Icon(Icons.delete),
            color: Colors.brown[400],
            onPressed: () {
              // Add item to removedItems list
              setState(() {
                removedItems.add(localCopy[index]);
                filteredItems.removeAt(index);
                localCopy.removeAt(index);
              });
            },
          ),
        ],
        ),
          SizedBox(height: 8.0),
          Text('Quantity: ${item.quantity}'),
          Text('Expiration Date: ${item.formattedDate}'),
          Text('Details/Notes: ${item.details.isEmpty ? '-' : item.details}'),
          SizedBox(height: 8.0),
          Row(
            children: [
              Text('                                                           '),
              SizedBox(width: 8.0),
              _buildQuantityButton(Icons.remove, () {
                adjustQuantity(index, -1); // Decrease quantity
              }),
              Text(''),
              SizedBox(width: 8.0),
              _buildQuantityText(localCopy[index].quantity),
              Text(''),
              SizedBox(width: 8.0),
              _buildQuantityButton(Icons.add, () {
                adjustQuantity(index, 1); // Increase quantity
              }),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildQuantityContainer(String quantity) {
    return Container(
      width: 50.0,
      height: 30.0,
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: Colors.black),
        borderRadius: BorderRadius.circular(5.0),
      ),
      child: Center(
        child: Text(
          quantity,
          style: TextStyle(
            fontSize: 16.0,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  Widget _buildQuantityText(String quantity) {
    return Container(
      width: 40.0,
      height: 30.0,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(5.0),
      ),
      child: Center(
        child: Text(
          quantity,
          style: TextStyle(
            fontSize: 16.0,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  Widget _buildQuantityButton(IconData icon, VoidCallback onPressed) {
    return Container(
      width: 30.0,
      height: 30.0,
      decoration: BoxDecoration(
        color: Colors.brown[400],
        shape: BoxShape.circle,
      ),
      child: Center(
        child: IconButton(
          icon: Icon(
            icon,
            color: Colors.pink[100],
          ),
          onPressed: onPressed,
        ),
      ),
    );
  }


  void filterItems(String query) {
    setState(() {
      filteredItems = localCopy
          .where((item) =>
      item.itemName.toLowerCase().contains(query.toLowerCase()) ||
          item.details.toLowerCase().contains(query.toLowerCase()))
          .toList();
    });
  }

  void adjustQuantity(int index, int change) {
    setState(() {
      int currentQuantity = int.parse(localCopy[index].quantity);
      int newQuantity = currentQuantity + change;

      // Ensure the new quantity is within bounds
      if (newQuantity >= 0 && newQuantity <= int.parse(widget.foodItems[index].quantity)) {
        localCopy[index] = localCopy[index].copyWith(quantity: newQuantity.toString());
      }
    });
  }
}


class CameraPage extends StatefulWidget {
  final FoodItem newItem;

  CameraPage({required this.newItem});

  @override
  _CameraPageState createState() => _CameraPageState();
}

class _CameraPageState extends State<CameraPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        // Your app bar content goes here
      ),
      body: ListView(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(8.0),
              child: Image.asset(
                'images/camera1,jpg.jpg', // Replace with your image asset path
                fit: BoxFit.cover, // Use BoxFit.cover to make the image cover the available space
              ),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              // Save information and navigate back to YourItemsPage
              Navigator.pop(context, widget.newItem);
            },
            child: Text(
              'Save',
              style: TextStyle(
                fontFamily: 'EBGaramond',
                fontWeight: FontWeight.w900,
                fontSize: 16.0,
                color: Colors.black,
              ),
            ),
            style: ElevatedButton.styleFrom(
              primary: Colors.pink[200], // Set the button's background color to white
              elevation: 0,
            ),
          ),
        ],
      ),
    );
  }
}

class FoodItem {
  final String itemName;
  final String quantity;
  final DateTime? expirationDate;
  final String details;

  FoodItem({
    required this.itemName,
    required this.quantity,
    required this.expirationDate,
    required this.details,
  });

  FoodItem copyWith({
    String? itemName,
    String? quantity,
    DateTime? expirationDate,
    String? details,
  }) {
    return FoodItem(
      itemName: itemName ?? this.itemName,
      quantity: quantity ?? this.quantity,
      expirationDate: expirationDate ?? this.expirationDate,
      details: details ?? this.details,
    );
  }

  String get formattedDate {
    return expirationDate != null ? "${expirationDate!.toLocal().toString().split(' ')[0]}" : "";
  }
}

class ScanPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new_rounded, color: Colors.black),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Column(
        children: [
          SizedBox(height: 30.0), // Add some space at the top
          Expanded(
            child: Center(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    'Add Your Item',
                    style: TextStyle(
                      fontFamily: 'PlayfairDisplay',
                      fontWeight: FontWeight.w900,
                      fontSize: 30.0,
                    ),
                  ),
                  SizedBox(height: 26.0),
                  Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10.0),
                      gradient: LinearGradient(
                        colors: [
                          Colors.yellow.shade300,
                          Colors.pink.shade100,
                        ],
                      ),
                    ),
                    child: TextButton(
                      onPressed: () {
                        showHelpDialog(context);
                      },
                      child: Text(
                        'Need Help ?',
                        style: TextStyle(
                          fontFamily: 'EBGaramond',
                          fontWeight: FontWeight.w900,
                          fontSize: 16.0,
                          color: Colors.black,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 25.0),
                  // Display QR code image (You can replace the placeholder image with a dynamic QR code)
                  Image.asset(
                    'images/qr code 2.jpg', // Replace with the path to your QR code image
                    width: 300.0,
                    height: 300.0,
                  ),
                  SizedBox(height: 25.0),
                  Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        _buildActionButton('QR from Photos', Icons.photo, () {
                          // Handle QR from Photos button tap
                        },
                            width: 160.0), // Set the width to 160.0 to match the "Need Help" button
                        SizedBox(width: 10.0),
                        _buildActionButton('Flash', Icons.flash_on, () {
                          // Handle flash camera button tap
                        }, isCircular: true, width: 90.0), // Set the width to 160.0 to match the "Need Help" button
                      ],
                    ),
                  ),
                  SizedBox(height: 35.0),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ElevatedButton(
                        onPressed: () {
                          navigateToScanPage(context);
                        },
                        style: ElevatedButton.styleFrom(
                          primary: Colors.orange[100],
                        ),
                        child: Container(
                          width: 120.0,
                          height: 50.0,
                          child: Center(
                            child: Text(
                              'Scan',
                              style: TextStyle(
                                fontFamily: 'PlayfairDisplay',
                                fontSize: 20.0,
                                fontWeight: FontWeight.w900,
                                color: Colors.black,
                              ),
                            ),
                          ),
                        ),
                      ),
                      Container(
                        width: 10.0,
                        height: 50.0,
                        color: Colors.black,
                      ),
                      ElevatedButton(
                        onPressed: () {
                          navigateToManualPage(context);
                        },
                        style: ElevatedButton.styleFrom(
                          primary: Colors.orange[100],
                        ),
                        child: Container(
                          width: 120.0,
                          height: 50.0,
                          child: Center(
                            child: Text(
                              'Manually',
                              style: TextStyle(
                                fontFamily: 'PlayfairDisplay',
                                fontSize: 20.0,
                                fontWeight: FontWeight.w900,
                                color: Colors.black,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  void navigateToScanPage(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ScanPage(),
      ),
    );
  }

  void navigateToManualPage(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ManualPage(
          onAddItem: (FoodItem newItem) {
            // Handle the item addition as needed in your app
          },
        ),
      ),
    );
  }


  Widget _buildActionButton(String label, IconData icon, VoidCallback onPressed, {bool isCircular = false, double width = 160.0}) {
    return Container(
      width: width, // Set a fixed width for the buttons
      height: isCircular ? 65.0 : null,
      decoration: isCircular
          ? BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          colors: [
            Colors.yellow.shade300,
            Colors.pink.shade100,
          ],
        ),
      )
          : BoxDecoration(
        borderRadius: BorderRadius.circular(10.0),
        gradient: LinearGradient(
          colors: [
            Colors.yellow.shade300,
            Colors.pink.shade100,
          ],
        ),
      ),
      child: TextButton(
        onPressed: onPressed,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              color: Colors.black,
              size: 20.0,
            ),
            SizedBox(height: 0.0),
            Text(
              label,
              style: TextStyle(
                fontFamily: 'EBGaramond',
                fontWeight: FontWeight.w900,
                fontSize: 14.0,
                color: Colors.black,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> showHelpDialog(BuildContext context) async {
    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Help'),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _helpText('There are 2 options: '),
                _helpText('1. Scan directly to the QR code.'),
                _helpText('2. Click on QR from Photos and select your QR code picture.'),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Close'),
            ),
          ],
        );
      },
    );
  }

  Widget _helpText(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0),
      child: Text(text),
    );
  }
}
