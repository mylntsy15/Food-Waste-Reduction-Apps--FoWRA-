import 'dart:async';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DatabaseHelper {
  Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;

    // If _database is null, instantiate it
    _database = await initDatabase();
    return _database!;
  }

  Future<Database> initDatabase() async {
    String path = join(await getDatabasesPath(), 'ingredients.db');
    return await openDatabase(path, version: 1, onCreate: _createDatabase);
  }

  Future<void> _createDatabase(Database db, int version) async {
    // Create your tables here
    await db.execute('''
      CREATE TABLE recipes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        ingredients TEXT,
        steps TEXT
      )
    ''');
    // Insert initial data if it doesn't exist
    await _insertInitialData(db);

  }

  Future<void> _insertInitialData(Database db) async {
    // Example initial data
    List<Map<String, dynamic>> initialRecipes = [
      {'name': 'Leftover Squash Pancakes',
        'ingredients': '250g leftover roasted squash, 250g leftover roasted squash, 2 leaves rosemary,'
            '30g Parmesan cheese, 1 egg, 280ml milk, 280ml milk',
        'steps': '1.In a large bowl, combine the flour, baking powder, salt, and black pepper. Mix well. '
            '2.In another bowl, beat the eggs. Add the grated squash, chopped onion (if using), and fresh herbs. Mix until well combined.'
            '3.Add the wet ingredients to the dry ingredients and stir until just combined. Do not overmix; a few lumps are okay.'
            '3.Add the wet ingredients to the dry ingredients and stir until just combined. Do not overmix; a few lumps are okay.'
            '4. Heat a skillet or griddle over medium heat and add a bit of olive oil or butter to coat the surface.'
            '5. Spoon the batter onto the hot griddle to form pancakes. Use about 1/4 cup of batter for each pancake.'
            '6. Cook until bubbles form on the surface of the pancake and the edges start to look set. This usually takes 2-3 minutes.'
            '7. Flip the pancakes and cook for an additional 1-2 minutes, or until golden brown on the other side.'},
      {'name': 'Homemade Pickle',
        'ingredients': '1 cup white vinegar,'
            '6-8 pickling cucumbers'
            '1 cup water'
            '2 tablespoons salt'
            '1 tablespoon sugar'
            '2 cloves garlic, minced'
            '1 teaspoon dill seeds'
            '1 teaspoon mustard seeds'
            '1/2 teaspoon black peppercorns'
            '1/2 teaspoon red pepper flakes (optional)',
        'steps': '1. Wash the cucumbers thoroughly and slice them into rounds or spears.'
            '2. In a saucepan, combine water, vinegar, salt, and sugar. Bring to a simmer until the salt and sugar dissolve. Remove from heat and let it cool.'
            '3. Place the cucumber slices, garlic, dill seeds, mustard seeds, black peppercorns, and red pepper flakes (if using) in a clean, sterilized jar.'
            '4. Pour the cooled vinegar mixture over the cucumbers, ensuring they are fully submerged.'
            '5. Seal the jar and refrigerate for at least 24 hours before consuming.'
            '6. Enjoy your homemade pickles!'},
      // Add more initial data as needed
    ];

    // Check if data already exists before inserting
    for (Map<String, dynamic> recipe in initialRecipes) {
      List<Map<String, dynamic>> existingData = await db.query(
        'recipes',
        where: 'name = ?',
        whereArgs: [recipe['name']],
      );

      if (existingData.isEmpty) {
        await db.insert('recipes', recipe);
      }
    }
  }

  // Search function to retrieve recipes containing the specified ingredient
  Future<List<Map<String, dynamic>>> searchRecipesByIngredient(String ingredient) async {
    final Database db = await database;

    // Use the LIKE statement to perform a partial match search
    return await db.rawQuery('''
      SELECT * FROM recipes
      WHERE ingredients LIKE ?
    ''', ['%$ingredient%']);
  }

// Add your database-related functions here
}
