import 'package:flutter/material.dart';
import 'recipepage.dart';
import 'MainPageDonation.dart';
import 'item_inventory.dart';
import 'expired.dart';
import 'WritePost.dart';

class HomePageModel {
  // You can add your business logic here
}

class HomePageWidget extends StatefulWidget {
  final HomePageModel model;

  const HomePageWidget({Key? key, required this.model}) : super(key: key);

  @override
  _HomePageWidgetState createState() => _HomePageWidgetState();
}

class _HomePageWidgetState extends State<HomePageWidget> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: Padding(
          padding: const EdgeInsets.all(0.0),
          child: IconButton(
            icon: Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
        ),
        title: Text(
          'FoWRA',
          style: TextStyle(
            fontSize: 25,
            fontFamily: 'PlayfairDisplay',
            color: Colors.white,
            letterSpacing: 1.5,
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.pinkAccent.withOpacity(0.7),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(bottom: Radius.circular(15)),
        ),
        elevation: 0,
        actions: [
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: IconButton(
              icon: Icon(Icons.help, color: Colors.white, size: 25.0),
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return AlertDialog(
                      title: Text(
                        'Help',
                        style: TextStyle(
                          fontSize: 30,
                          fontFamily: 'Signika',
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      content: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            'Welcome!',
                            style: TextStyle(fontSize: 20, fontFamily: 'PlayfairDisplay'),
                          ),
                          SizedBox(height: 10),
                          Text(
                            'Make a Donation provides you with the opportunity to request a donation, and a dedicated representative from the food bank will promptly arrange to pick it up at your convenience.',
                            style: TextStyle(fontSize: 15),
                          ),
                          SizedBox(height: 10),
                          Text(
                            'Your Donations provides you with the list of donation that you have been created.',
                            style: TextStyle(fontSize: 15),
                          ),
                          SizedBox(height: 10),
                          Text(
                            'Contact us if any problem occurs!',
                            style: TextStyle(fontSize: 15),
                          ),
                        ],
                      ),
                      actions: [
                        TextButton(
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          child: Text(
                            'Close',
                            style: TextStyle(fontSize: 20, fontFamily: 'Sans', color: Colors.pink),
                          ),
                        ),
                      ],
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
      backgroundColor: Color(0xFFFAF5E8),
      body: ListView(
        padding: EdgeInsets.symmetric(horizontal: 20, vertical: 50),
        children: [
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(height: 20),
                CircleAvatar(
                  backgroundColor: Colors.pinkAccent.withOpacity(0.7),
                  child: IconButton(
                    icon: Icon(Icons.person, color: Colors.white),
                    onPressed: () {
                      // Add functionality for the profile button
                      print('Profile button pressed');
                    },
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  'Hello there,',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  'Say no to wastage!!!',
                  style: TextStyle(
                    fontSize: 18,
                    color: Colors.black54,
                  ),
                ),
                SizedBox(height: 20),
                ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: Image.asset(
                    'images/homescreen.jpg',
                    width: 500,
                    height: 200,
                    fit: BoxFit.fitWidth,
                  ),
                ),
                SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Expanded(
                      child: ModernStyledButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => ItemInventory()),
                          );
                        },
                        icon: Icons.storage,
                        label: 'Item\nInventory',
                        symbolColor: Colors.lightGreen, // Set the symbol color to light green
                      ),
                    ),
                    SizedBox(width: 20),
                    Expanded(
                      child: ModernStyledButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => WritePostPage()),
                          );
                        },
                        icon: Icons.people,
                        label: 'Community\nEngagement',
                        symbolColor: Colors.lightBlue, // Set the symbol color to light blue
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Expanded(
                      child: ModernStyledButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => RecipePage()),
                          );
                        },
                        icon: Icons.restaurant,
                        label: 'Recipe\nSuggestions',
                        symbolColor: Colors.yellow, // Set the symbol color to yellow
                      ),
                    ),
                    SizedBox(width: 20),
                    Expanded(
                      child: ModernStyledButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => MainPage()),
                          );
                        },
                        icon: Icons.favorite,
                        label: 'Make a\nDonation',
                        symbolColor: Colors.redAccent, // Set the symbol color to light red
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Expanded(
                      child: ModernStyledButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => MyApp()),
                          );
                        },
                        icon: Icons.date_range,
                        label: 'Expiration\nTracker',
                        symbolColor: Colors.brown, // Set the symbol color to yellow
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class ModernStyledButton extends StatelessWidget {
  final VoidCallback? onPressed;
  final IconData icon;
  final String label;
  final Color symbolColor; // New property for symbol color

  const ModernStyledButton({
    Key? key,
    this.onPressed,
    required this.icon,
    required this.label,
    required this.symbolColor,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        primary: Colors.pinkAccent.withOpacity(0.7), // Keep the button color the same
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        padding: EdgeInsets.all(20),
        minimumSize: Size(150, 150),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            icon,
            size: 40,
            color: symbolColor, // Use the provided symbol color
          ),
          SizedBox(height: 12),
          Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 14,
              color: Colors.white,
            ),
          ),
        ],
      ),
    );
  }
}
